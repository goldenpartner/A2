function brand()
  print_with_color(:white,"        _                       _ \n")
  print_with_color(:white,"       | |                     (_)\n")
  print_with_color(:white,"  ___  | |__     ___     __ _   _ \n")
  print_with_color(:white," / __| | '_ \\   / _ \\   / _` | | |\n")
  print_with_color(:white," \\__ \\ | | | | | (_) | | (_| | | |\n")
  print_with_color(:white," |___/ |_| |_|  \\___/   \\__, | |_|\n")
  print_with_color(:white,"                         __/ |    \n")
  print_with_color(:white,"                        |___/     \n\n")
end

function meun()
  print_with_color(:blue,"       ---------------------\n")
  print_with_color(:blue,"                menu\n")
  print_with_color(:blue,"       ---------------------\n")
  print_with_color(:blue,"	       1.Play\n")
  print_with_color(:blue,"               2.About\n")
  print_with_color(:blue,"               3.Exit\n")
end

function about()
  println("\n         Japanese Chess V1.0")
  println("Entirely coded and produced by group GGWP")
  return
end
